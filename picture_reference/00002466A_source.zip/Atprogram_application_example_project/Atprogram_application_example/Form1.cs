﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;
using System.Threading;

namespace Atprogram__example
{
    public partial class Form1 : Form
    {
        public string fwfilename, atprogrampath;
    
        public Form1()
        {
            InitializeComponent();

            if (File.Exists(@"applicationparameter.txt"))
            {
                StreamReader sr = new StreamReader(@"applicationparameter.txt", Encoding.Default);
                fwfilename = sr.ReadLine();
                textBox2.Text = fwfilename;
                atprogrampath = sr.ReadLine();
                textBox1.Text = atprogrampath;
                sr.Close();
            }
            else
            {

                FileStream fs = new FileStream("applicationparameter.txt", FileMode.Create);
                fs.Close();
            }
                

        }


        public StreamReader RunProgram_atprogram(String programName, String cmd, String programPath)
        {
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.CreateNoWindow = true;
            proc.StartInfo.FileName = programName;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.RedirectStandardError = true;
            proc.StartInfo.RedirectStandardInput = true;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.Start();
            if (programPath.Length > 13)
            {
                proc.StandardInput.WriteLine(programPath[0].ToString() + ":");
                if (cmd.Length != 0)
                {
                    proc.StandardInput.WriteLine("cd " + programPath.Substring(0, (programPath.Length - 13)));
                }
            }
            proc.StandardInput.WriteLine(cmd);
            //info = proc.StandardOutput.ReadToEnd();           //放在该位置不行，该语句会死掉，原因未知
            proc.StandardInput.WriteLine("exit");
            StreamReader reader = proc.StandardOutput;          //截取输出流
            proc.Close();
            return reader;
        }

        private void program_Click(object sender, EventArgs e)
        {
            StreamReader reader;
            string outline;
            string failflag=null;

            if ((textBox1.Text =="") || (textBox2.Text == ""))
            {
                MessageBox.Show("Please choose atpgrogram.exe application and programming file");
                return;
            }

            program_status.Clear();
            program_status.AppendText("Programming...");
                
            // chip erase
          
            reader = RunProgram_atprogram("cmd.exe", "atprogram -t atmelice -i ISP -d atmega328pb chiperase", textBox1.Text);
            while (!reader.EndOfStream)
            {
                outline = reader.ReadLine();
                cmd_execution_info.AppendText(outline + "\r\n");
                if (outline.Length > 8)
                {
                    if (outline.Substring(0, 8) == "Firmware")
                    {
                        failflag = reader.ReadLine();
                        cmd_execution_info.AppendText(failflag + "\r\n");
                    }
                }
                            
            }
            if (failflag != ("Chiperase completed successfully"))
            {
                program_status.Clear();
                program_status.AppendText("Fail");
                return;
            }
          
            // program hex file
            reader = RunProgram_atprogram("cmd.exe", "atprogram -t atmelice -i ISP -d atmega328pb program -f  "+textBox2.Text+" --verify",textBox1.Text);
            while (!reader.EndOfStream)
            {
                outline = reader.ReadLine();
                cmd_execution_info.AppendText(outline + "\r\n");
                if (outline.Length > 8)
                {
                    if (outline.Substring(0, 8) == "Firmware")
                    {
                        failflag = reader.ReadLine();
                        cmd_execution_info.AppendText(failflag + "\r\n");
                    }
                }

            }
            if (failflag != ("Programming and verification completed successfully."))
            {
                program_status.Clear();
                program_status.AppendText("Fail");
                return;
            }
           
            // program  lock bit
            reader = RunProgram_atprogram("cmd.exe", "atprogram -t atmelice -i ISP -d atmega328pb write -lb --values c0 ", textBox1.Text);
            while (!reader.EndOfStream)
            {
                outline = reader.ReadLine();
                cmd_execution_info.AppendText(outline + "\r\n");
                if (outline.Length > 8)
                {
                    if (outline.Substring(0, 8) == "Firmware")
                    {
                        failflag = reader.ReadLine();
                        cmd_execution_info.AppendText(failflag + "\r\n");
                    }
                }

            }
            if (failflag != ("Write completed successfully."))
            {
                program_status.Clear();
                program_status.AppendText("Fail");
                return;
            }
           if (cmd_execution_info.Lines.Length > 1000) cmd_execution_info.Clear();

           program_status.Clear();
           program_status.AppendText("Success");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         
        }
        
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
          
           

            if ((fwfilename != textBox2.Text) || (atprogrampath != textBox1.Text))
            {
                StreamWriter sr = new StreamWriter(@"applicationparameter.txt");
                sr.WriteLine(textBox2.Text);
                sr.WriteLine(textBox1.Text);
                sr.Close();
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //FolderBrowserDialog dialog = new FolderBrowserDialog();
            //dialog.Description = "please atprogram.exe directory";
            //if (dialog.ShowDialog() == DialogResult.OK)
            //{
            //     textBox1.Text = dialog.SelectedPath;
            //}

            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = false;
            fileDialog.Title = "please select programming file";
            fileDialog.Filter = "All files(*.*)|*.*";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = fileDialog.FileName;
                
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = false;
            fileDialog.Title = "please select programming file";
            fileDialog.Filter = "All files(*.*)|*.*";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = fileDialog.FileName;
                             
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }

        private void cmdtext_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
